
//________________________________________________________


var some = 10
// Not Pure Function
fun someFunction(x: Int) = x + 10 + some

// Function Type
//		(Int, Int) -> Int
// Pure Function
//		Function Without Side Effects
//		(a, b, result)

fun sum( a: Int, b: Int ) : Int { return a + b + someFunction( 99 ) }
fun sub( a: Int, b: Int ) : Int { return a - b }

// Object Oriented Paradigm
//		Polymorphic Function

// Functional Paradigm
//		Higher Order Function
//			Functions Which Takes And/Or Returns Function

// Type Theory : Function Type
//		(Int, Int, (Int, Int) -> Int ) -> Int

fun calculator( a: Int, b: Int, operation: (Int, Int) -> Int ) : Int {
	return operation( a, b )
}

fun playWithCalculator() {
	val a = 40
	val b = 10
	var result: Int

	result = calculator( a, b, ::sum )
	println("Result : $result")

	result = calculator( a, b, ::sub )
	println("Result : $result")	

	// val something: Int = ::sum
	val something: (Int, Int) -> Int = ::sum
	result = something( 10, 20 );
	println("Result : $result")		

	val somethingAgain: (Int, Int, (Int, Int) -> Int) -> Int = ::calculator
	println("Value: $somethingAgain")
}

//________________________________________________________

fun forward( step: Int ) 	= step + 1
fun backward( step: Int )	= step - 1


// Functional Paradigm
//		Higher Order Function
//			Functions Which Takes And/Or Returns Function
fun chooseSteps( choice: Boolean ) : (Int) -> Int {
	if ( choice ) {
		return ::forward
	} else {
		return ::backward
	}
}

fun chooseStepsAgain( choice: Boolean ) = if (choice) {
	::forward } else {
	::backward
}

fun playWithChooseSteps() {
	val something: (Boolean) -> (Int) -> Int = ::chooseSteps
	val somethingAgain: (Int) -> Int = something( true )
	val somethingMore = somethingAgain( 99 )
}


//________________________________________________________

// Polymorphic Function
// 		Mecahnims: Arguments With Default Values
fun somePolymorphicsFunction( a: Int = 10, b: Int = 0, greeting: String = "Hello" ) {
	println( a )
	println( b )
	println( greeting )
}

fun playWithPolymorphicFunction() {
	somePolymorphicsFunction()
	somePolymorphicsFunction( a = 99 )
	somePolymorphicsFunction( a = 99, b = 999 )
	somePolymorphicsFunction( a = 99, b = 999, greeting = "Good Morning!" )
}

//________________________________________________________
//________________________________________________________
//________________________________________________________

fun main() {
	println("\nFunction: playWithCalculator")
	playWithCalculator()

	println("\nFunction: playWithChooseSteps")
	playWithChooseSteps()

	println("\nFunction: playWithPolymorphicFunction")
	playWithPolymorphicFunction()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")	
}

//________________________________________________________
