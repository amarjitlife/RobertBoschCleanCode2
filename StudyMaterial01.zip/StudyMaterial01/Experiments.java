

//________________________________________________________


// DESIGN PRINCIPLE
//		Design Towards Abstract Types Rather Than Concerete Types
//		Abstract Type = { Operations, Phi }
//		Type = { Operations, Range }

// Corollary
//		Design Towards Interfaces Rather Than Concrete Classess
//		Design Towards Pure Abstract Classes Rather Than Concrete Classess

/*
1. Abstraction
			Abstract Type = { Operations, {} }
			Type = { Operations, Range }

*/
// Superpower Is Abstract Type
//		Operations 	= { fly, saveWorld }
//		Range 		= { } 
interface Superpower {
	public void fly();
	public void saveWorld();
}

// Spiderman Is A Type
//		Spiderman Is Also Type Of Superpower
class Spiderman implements Superpower {
	public void fly() 	{ System.out.println("Fly Like Spiderman!"); }
	public void saveWorld() { System.out.println("Save World Like Spiderman!"); }
}

// Superman Is A Type
//		Superman Is Also Type Of Superpower
class Superman implements Superpower {
	public void fly() 	{ System.out.println("Fly Like Superman!"); }
	public void saveWorld() { System.out.println("Save World Like Superman!"); }
}

class Heman implements Superpower {
	public void fly() 	{ System.out.println("Fly Like Heman!"); }
	public void saveWorld() { System.out.println("Save World Like Heman!"); }
}

class Wonderwoman implements Superpower {
	public void fly() 	{ System.out.println("Fly Like Wonderwoman!"); }
	public void saveWorld() { System.out.println("Save World Like Wonderwoman!"); }
}

class Hanumanji implements Superpower {
	public void fly() 	{ System.out.println("Fly Like Hanumanji!"); }
	public void saveWorld() { System.out.println("Save World Like Hanumanji!"); }
}

//________________________________________________________
// Code Reuse
// 	Using Mechanism Inheritance
//class Human extends Spiderman {
//class Human extends Superman {
//class Human extends Heman {
class Human extends Wonderwoman {
	public void fly() 	{ super.fly(); 	    }//{ System.out.println("Fly Like Human!"); }
	public void saveWorld() { super.saveWorld(); }//{ System.out.println("Save World Like Human!"); }
}

//________________________________________________________

// Code Reuse
// 	Using Mechanism Composition
class HumanBetter  {
	//Spiderman power = new Spiderman();
	//Superman power = new Superman();
	Wonderwoman power = new Wonderwoman();
	public void fly() 		{ power.fly(); 	    }
	public void saveWorld() { power.saveWorld(); }
}

//________________________________________________________

// Code Reuse
// 	Using Mechanism Composition

// class/Type Polymorphicß 
class HumanBest  {
	// Abstract Type
	Superpower power = null;
	public void fly() 		{ if ( power != null ) power.fly(); 	   }
	public void saveWorld() { if ( power != null ) power.saveWorld();  }
}

//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________

public class Experiments {
	public static void playWithHuman() {
		Human h = new Human();
		h.fly();
		h.saveWorld();
	}

	public static void playWithHumanBetter() {
		HumanBetter hb = new HumanBetter();
		hb.fly();
		hb.saveWorld();
	}
	
	public static void playWithHumanBest() {
		HumanBest hb = new HumanBest();
		hb.fly();
		hb.saveWorld();

		hb.power = new Spiderman();
		hb.fly();
		hb.saveWorld();
		
		hb.power = new Superman();
		hb.fly();
		hb.saveWorld();

		hb.power = new Hanumanji();
		hb.fly();
		hb.saveWorld();		
	}

	public static void main( String[] args ) {
		System.out.println("Welcome Boschler!!!");

		System.out.println("\nFunction: playWithHuman");
		playWithHuman();

		System.out.println("\nFunction: playWithHumanBetter");
		playWithHumanBetter();

		System.out.println("\nFunction: playWithHumanBest");
		playWithHumanBest();
/*
		System.out.println("\nFunction: ");
		System.out.println("\nFunction: ");
		System.out.println("\nFunction: ");
*/	
	}
}

//________________________________________________________


