__________________________________________________

DAY 02
__________________________________________________

	ASSIGNMENT A1: Practice Ideas and Code

	ASSIGNMENT A2: Reading and Practice Assignment
		Read and Practice Code Examples From Following Chapters
			Chapter 10: Better Structures
			Chatper 11: Object Oriented Programming In C
	
			Reference Book: 21st Century C, 2nd Edition
__________________________________________________

DAY 03
__________________________________________________

	ASSIGNMENT A1: Practice Ideas and Code

	ASSIGNMENT A2: Reading and Practice Assignment
		Read and Practice Code Examples From Following Chapters
			Chapter 03: Be Principled
			Chatper 07: Functional Programmingss
	
			Clean C++20	Sustainable Software Development
				Patterns and Best Practices
				Second Edition
__________________________________________________
__________________________________________________
__________________________________________________
__________________________________________________

Learn C++ [ THROUGHLY ]

	Level 00:
		1. Complete Reference C++, Herbt Schildt
			Focuses On Only Syntax

	Level 01:
		1. Thinking In C++, Volume I, 	Bruce Eckel
		2. Thinking In C++, Volume II, 	Bruce Eckel
			Both Books Discussion Code Design
			Anyone 
	
	Level 02:
		1. C++ Programming Language, Bjarne Stratroup
			Good Reference Book
			For 4+ Years Experience
		2. C++ Primer, Lippman

	Level 03:
		1. Effective C++, Scott Mayer
		2. More Effective C++, Scott Mayer
		3. Effective Modern C++
		4. Modern C++ Design, Andre
		5. Exceptional C++

Learn C [ THROUGHLY ]

	Level 01:
		1. The C Programming Langauge, 2nd Edition
				Kernigam and Dennis Rithice
		2. 21st Century C

Learn Java [ THROUGHLY ]

	Level 00:
		1. Complete Reference Java, Herbt Schildt
			Focuses On Only Syntax

	Level 01:
		1. Core Java For Impatient, Cay Hortsman

	Level 02:
		1. Effective Java

Software/System Design

	Level 01:
		1. Practical Object-Oriented Design: 
			An Agile Primer Using Ruby 2nd Edition by Sandi Metz
		
		2. Data Structures and Program Design in C++ First Edition
			by Robert L. Kruse (Author), Alexander J. Ryba (Author)

	Level 02:
		Agile Software Development, Principles, Patterns and Practices
			Robert Martin

	Level 03:
		Design Patterns: Elements of Reusable Object-Oriented Software 
		1st Edition
			Erich Gamma (Author), Richard Helm (Author), & 3 more

Foundational/Fundamentals Books
	
	Level 01:
		Structure and Interpretation of Computer Program, MIT
		by Harold Abelson , Gerald Jay Sussman , et al.

	Level 02
		Types and Programming Langauges, Benjamin Pierce

__________________________________________________
__________________________________________________
__________________________________________________
__________________________________________________
__________________________________________________
__________________________________________________
__________________________________________________
