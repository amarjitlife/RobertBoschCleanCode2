
//________________________________________________________


Write Following sum Function
//		1. Return Valid Arithmatic Sum
//		2. Print Can't Calculate Sum For Given a And b

// DESIGN 01
	int sum(int a, int b) {
		return a + b;
	}

//________________________________________________________
// DESIGN 02

	if INT_MIN < a, b < INT_MAX
		sum = a + b
	else 
		error


	INT_MIN < a, b < INT_MAX
	sum = a + b

	INT_MIN < sum < INT_MAX

	else
		Error

//________________________________________________________
// DESIGN 03

	sizeof( sum ) > sizeof( a )

//________________________________________________________

#include <limits.h>
  
void sum(signed int si_a, signed int si_b) {
  signed int sum;
  if (((si_b > 0) && (si_a > (INT_MAX - si_b))) ||
      ((si_b < 0) && (si_a < (INT_MIN - si_b)))) {
    /* Handle error */
  } else {
	    sum = si_a + si_b;
  }¯
  /* ... */
}

//________________________________________________________
//________________________________________________________
//________________________________________________________

https://github.com/amarjitlife/RobertBoschCleanCode2/
https://github.com/amarjitlife/RobertBoschCleanCode2/
https://github.com/amarjitlife/RobertBoschCleanCode2/
https://github.com/amarjitlife/RobertBoschCleanCode2/

//________________________________________________________

