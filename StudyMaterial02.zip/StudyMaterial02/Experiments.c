

#include <stdio.h>

typedef struct human_type {
	int id;
	char name[100];
	void (*dance)();
	void (*sing)();
} Human;


//_____________________________________________________

void doBhangra() { printf("\nDoing Bhangra... Oyee Hoyeee!!!"); }
void doHipHop()  { printf("\nDoing Hip Hope..."); }

void doHindiMusic() { printf("\nHindi Music Singing..."); }
void doBanglaMusic() { printf("\nBangla Music Singing..."); }

void playWithHuman() {
	Human gabbar = { 420, "Gabbar Singh", doBhangra, doHindiMusic };
	printf("\nID: %d", gabbar.id );
	printf("\nName: %s", gabbar.name);
	gabbar.dance();
	gabbar.sing();

	Human basanti = { 100, "Basanti", doHipHop, doBanglaMusic };
	printf("\nID: %d", basanti.id );
	printf("\nName: %s", basanti.name);
	basanti.dance();
	basanti.sing();
}

//_____________________________________________________

int sum( int a, int b ) { return a + b; }
int sub( int a, int b ) { return a - b; }

int mul( int a, int b ) { return a * b; }

// Polymorphic Function
//		Using Mechanism: By Passing Function To Function
//							 Callback Function

// Single Responsibility Principle
// Open-Close Principle
int calculate(int a, int b, int (*operation)(int, int) ) {
	return operation(a, b);
}

int calculator(Contex context)  {
	int (*operation)(int, int) = null;

	if context.ADD :
		operation = sum
	if context.SUB :
		operation

	calculate( context.arg1, context.arg2, operation )
}

void playWithCalculator() {
	int a = 40, b = 10, result = 0;

	//						   Configuring Callback
	result = calculate( a, b, sum ); // Configuring With sum
	printf("\nResult: %d", result );

	result = calculate( a, b, sub ); // Configuring With sub
	printf("\nResult: %d", result );	

	result = calculate( a, b, mul ); // Configuring With sum
	printf("\nResult: %d", result );	
}

//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________

int main() {
	printf("\nFunction: playWithHuman ");
	playWithHuman();

	printf("\nFunction: playWithCalculator");
	playWithCalculator();

	// printf("\nFunction: ");
	// printf("\nFunction: ");
	// printf("\nFunction: ");
}

