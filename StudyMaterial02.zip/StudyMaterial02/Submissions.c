
//________________________________________________________


Write Following sum Function
//		1. Return Valid Arithmatic Sum
//		2. Print Can't Calculate Sum For Given a And b

// DESIGN 01
	int sum(int a, int b) {
		return a + b;
	}

//________________________________________________________
// DESIGN 02

	if INT_MIN < a, b < INT_MAX
		sum = a + b
	else 
		error


	INT_MIN < a, b < INT_MAX
	sum = a + b

	INT_MIN < sum < INT_MAX

	else
		Error

//________________________________________________________
// DESIGN 03

	sizeof( sum ) > sizeof( a )

//________________________________________________________

#include <limits.h>
  
void sum(signed int si_a, signed int si_b) {
  signed int sum;
  if (((si_b > 0) && (si_a > (INT_MAX - si_b))) || // isOverflow()
      ((si_b < 0) && (si_a < (INT_MIN - si_b)))) { // isUnderflow()
    /* Handle error */
  } else {
	    sum = si_a + si_b;
  }¯
  /* ... */
}

//________________________________________________________

#define VALID 		1
#define NOTVALID 	0
typedef struct optional_type {
	int value;
	char * valid;
} Optional;

Optional sum(signed int si_a, signed int si_b) {
  // signed int sum;
  Optional result = { 0, 0 };
  if (((si_b > 0) && (si_a > (INT_MAX - si_b))) || // isOverflow()
      ((si_b < 0) && (si_a < (INT_MIN - si_b)))) { // isUnderflow()
    /* Handle error */
  		result.valid = NULL;
  } else {
	    result.value = si_a + si_b;
  		result.valid = VALID;	
  }
  return result;
}


// Clinet Code

void playWithSum() {
		Optional total = sum( 99, 999 );
		if ( total.valid ) { printf("\nResult : ", total.value); }
}


//________________________________________________________

//________________________________________________________

https://github.com/amarjitlife/RobertBoschCleanCode2/
https://github.com/amarjitlife/RobertBoschCleanCode2/
https://github.com/amarjitlife/RobertBoschCleanCode2/
https://github.com/amarjitlife/RobertBoschCleanCode2/

//________________________________________________________


